import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const CreateEmployee = () =>{
    const[empId, changeempId] = useState("");
    const[empName, changeempName] = useState("");
    const[salary, changesalary] = useState("");
    const navigate = useNavigate();
    const [validation, valchange] = useState(false)


    const handleSubmit=(e)=>{
        e.preventDefault();
        const empData = {empId, empName, salary };

        fetch("http://localhost:5014/api/Emp",{
            method: 'POST',
            headers:{"content-type" : "application/json"},
            body:JSON.stringify(empData)
        }).then((res)=>{
            alert("Saved Successfully !!")
            navigate('/');

        }).catch((err)=>{
            console.log(err.message);
        })
    }
    return(
        <div>

            <div className="row">
                <div className="offset-lg-3 col-lg-6">
                    <form className="container" onSubmit={handleSubmit}>

                        <div className="card" style={{"textAlign" : "left"}}>
                            <div className="card-title">
                                <h2>Create Employee</h2>

                            </div>
                            <div className="card-body">
                                <div className="row">
                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Employee Id</label>
                                            <input required value={empId} onMouseDown={e=>valchange(true)} onChange={e=>changeempId(e.target.value)} className="form-control"></input>
                                            { empId.length == 0 && validation &&<span className="text-danger">Enter then ID</span>}
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Name</label>
                                            <input required value={empName} onMouseDown={e=>valchange(true)} onChange={e=>changeempName(e.target.value)}  className="form-control"></input>
                                            { empName.length ==0 && validation &&<span className="text-danger">Enter the Name</span>}
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <label>Salary</label>
                                            <input value={salary} onChange={e=>changesalary(e.target.value)} className="form-control"></input>
                                        </div>
                                    </div>

                                    <div className="col-lg-12">
                                        <div className="form-group">
                                            <button type="submit" className="btn btn-success">Save</button>
                                            <Link to={'/'}  className="btn btn-danger">Back</Link>
                                            
                                        </div>
                                    </div>

                                    

                                </div>

                            </div>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    );
}

export default CreateEmployee;