
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const DetailsEmployee = () =>{
    
    const{empId}= useParams();
    const [empdata,empdatachange]=useState("")

    useEffect(()=>{
        fetch(`http://localhost:5014/api/Emp/${empId}`).then((res)=>{
            return res.json();
        }).then((resp)=>{
            empdatachange(resp);
        }).catch((err)=>{
            console.log(err.message);
            
        })

    },[])
    return(
        <div>
             {empdata &&
                <h1>The Employee Name is : {empdata.empName}</h1>
             }
             
        </div>
    );
}

export default DetailsEmployee;