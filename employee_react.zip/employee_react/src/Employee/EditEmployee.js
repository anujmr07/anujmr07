const EditEmployee = () =>{
    
    return(
        <div>

        </div>
    );
}

export default EditEmployee;