import logo from './logo.svg';
import './App.css';
import{BrowserRouter,Route,Routes} from 'react-router-dom'
import Employee from './Employee/Empolyee';
import CreateEmployee from './Employee/CreateEmployee';
import EditEmployee from './Employee/EditEmployee';
import DetailsEmployee from './Employee/DetailsEmployee';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path='/' element={<Employee/>}></Route>
        <Route path= '/employee/create' element={<CreateEmployee />}></Route>
        <Route path= '/employee/edit/:empid' element={<EditEmployee />}></Route>
        <Route path= '/employee/detaits/:empid' element={<DetailsEmployee />}></Route>

        
      </Routes>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
